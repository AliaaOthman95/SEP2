package com.example.aliaa.sep2.model;

public class User {
    private String name;
    private String email;
    private String password;
    private String creditCard;

    public User(String userName, String userEmail, String userPassword,
                String userCreditCard) {
        this.name = userName;
        this.email = userEmail;
        this.password = userPassword;
        this.creditCard = userCreditCard;
    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPassword() {
        return this.password;
    }

    public String getCreditCard() {
        return this.creditCard;
    }
}

