package com.example.aliaa.sep2.controller;
import android.content.Context;
import android.util.Log;

import com.example.aliaa.sep2.model.SQLiteDBHelper;
import com.example.aliaa.sep2.model.User;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.example.aliaa.sep2.model.Book;

/**
 * Created by shereen on 4/19/2018.
 */

public class Engine {

    private static Engine instance = null ;
    private static SQLiteDBHelper db = null;
    public static Engine getInstance (Context context){

        if(instance == null){
            db = new SQLiteDBHelper(context);
            return new Engine();
        }
        return instance;
    }

    public boolean addUser(User user){
        Pattern peamil = Pattern.compile("[a-z0-9]+@[a-z]+\\.[a-z]{2,3}");
        Matcher m1 = peamil.matcher(user.getEmail());
        Pattern pPass = Pattern.compile("[0-9]{8,10}");
        Matcher m2 = pPass.matcher(user.getPassword());
        Pattern pcredit = Pattern.compile("[0-9]{10,14}");
        Matcher m3 = pPass.matcher(user.getCreditCard());

        if (!m1.find()){
            Log.d("print","****************");
            return false;
        }else if (!m2.find()){
            Log.d("print","********11********");
            return false;
        }else if (!m3.find()){
            Log.d("print","***************22**************");
            return false;
        }
        return db.addUser(user);
    }

    public boolean findUser(String email , String password){
        User user =  db.getUser(email);

        if (user != null && user.getPassword().compareTo(password) == 0 && (user.getEmail().compareTo(email)==0)){
            return true;
        }
        return false;
    }

    public void getAllUser(){
        db.getAllUsers();
    }

    public ArrayList<Book> getAllBooks (){

        return db.getAllBooks();
    }
    public void addBook(Book book){
        db.addBook(book);
    }
    public ArrayList <Book> search(String query, String filter){

        ArrayList <Book> books = null;

        if(filter.compareTo("category") == 0){
            books = db.getBooksByCategory(query);
        }else if(filter.compareTo("name") == 0){
            books = db.getBooksByTitle(query);
        }else if(filter.compareTo("zone") == 0){
            books = db.getBooksByZone(query);
        }else if(filter.compareTo("author") == 0){
            books = db.getBooksByAuthor(query);
        }else if(filter.compareTo("date") == 0){
            books = db.getBooksByDate(Integer.parseInt(query));
        }else {
            books =  getAllBooks();
        }
        return books;
    }
}


